int getSecInDay();

