#include <stdlib.h>
#include <stdio.h>

int main()
{
    getSecInDay();
    printf("Sec in day: %d,\n", getSecInDay());
    return 0;
}
