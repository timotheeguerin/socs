
int getSecInDay();

int getSecInDay()
{
    return 3600*24;

}
