package assig2;

public class Pair
{
	public int a;
	public int b;
}
