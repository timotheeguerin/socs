package GridProblem;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

public class MazeSolver
{
	private GridProblem g;
	private PriorityQueue<SolverState> queue = new PriorityQueue<>(1, new SolverStateComparator());
	private List<SolverState> evaluatedStates = new ArrayList<SolverState>();

	public MazeSolver(int x, int y, int m, double p)
	{
		try
		{
			g = new GridProblem(x, y, m, p);
			System.out.println("Generated maze: ");
			g.print();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void solve()
	{
		System.out.println("Start state:");
		State start = g.getStartState();
		start.print();
		queue.add(new SolverState(start, 0, 0, new ArrayList<Operator>()));
		solveState();
	}

	private void solveState()
	{
		while (!queue.isEmpty())
		{
			SolverState solverState = queue.poll();

			if (g.goalState.equals(solverState.getState()))
			{
				System.out.println("Found");
				List<Operator> path = solverState.getPath();
				System.out.println("Result: ");

				for (Operator op : path)
				{
					op.print();
				}
				return;
			}

			//Add the current state to the evaluated state list
			evaluatedStates.add(solverState);

			//Get all the legal operation and cycle.
			ArrayList<Operator> ops = g.getLegalOps(solverState.getState());
			for (Operator op : ops)
			{
				//Get the next state
				State nextState = g.nextState(solverState.getState(), op);
				
				//Calculate all the costs
				int nextStateCost = g.cost(solverState.getState(), op);
				int g = solverState.getgCost() + nextStateCost;
				double f = g + calculateHeuristics(solverState, nextState);
				
				// Get the state if it already exist in the queue
				SolverState existingState = getState(nextState);
				
				//Get the state if it has already been evaluated.
				SolverState evalState = getEvalState(nextState);
				
				// If the state has never been added or f is smaller
				if (existingState == null || (evalState != null && f < evalState.getfCost())
						|| (existingState != null && f < existingState.getfCost()))
				{
					if (existingState != null)
					{
						queue.remove(existingState);
					}
					if(evalState !=null)
					{
						evaluatedStates.remove(evalState);
					}
					
					// Expand the path
					List<Operator> nextStatePath = new ArrayList<Operator>(solverState.getPath());
					nextStatePath.add(op);
					queue.add(new SolverState(nextState, f, g, nextStatePath));
				}
			}
		}
	}

	private double calculateHeuristics(SolverState solverState, State s)
	{
		GridState goal = g.goalState;
		GridState curState = (GridState) s;
		double h1 = Math.sqrt(Math.pow(goal.i - curState.i, 2) + Math.pow(goal.j - curState.j, 2));
		int h2 = solverState.getPath().size();

		return 0.5 * h1 + 0.5 * h2;
	}

	private SolverState getState(State state)
	{
		Iterator<SolverState> iterator = queue.iterator();
		while (iterator.hasNext())
		{
			SolverState element = (SolverState) iterator.next();
			if (element.getState().equals(state))
			{
				return element;
			}
		}

		return null;
	}

	private SolverState getEvalState(State state)
	{
		Iterator<SolverState> iterator = evaluatedStates.iterator();
		while (iterator.hasNext())
		{
			SolverState element = (SolverState) iterator.next();
			if (element.getState().equals(state))
			{
				return element;
			}
		}

		return null;
	}

	public static void main(String[] args)
	{

		Scanner scanner = new Scanner(System.in);
		System.out.println("=======================================================");
		System.out.println("			MAZE SOLVER						   ");
		System.out.println("=======================================================");
		System.out.println();
		
		System.out.println("Chooose the size: ");
		System.out.print("x: ");
		int x = scanner.nextInt();
		System.out.print("y: ");
		int y = scanner.nextInt();
		
		System.out.print("Maximum cost: ");
		int m = scanner.nextInt();
		
		System.out.print("Wall purcent: ");
		double p = scanner.nextDouble();
		
		MazeSolver solver = new MazeSolver(x, y, m, p);
		solver.solve();

	}
}
