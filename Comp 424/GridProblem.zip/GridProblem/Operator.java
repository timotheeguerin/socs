package GridProblem;

public interface Operator
{

	public void print();
}