package GridProblem;

import java.util.ArrayList;
import java.util.List;

public class SolverState
{
	private State state;
	//f=g+h
	private double fcost;
	//g
	private int gcost;
	
	private List<Operator> path = new ArrayList<Operator>();

	public SolverState(State state, double cost, int costPath,List<Operator> path)
	{
		this.state = state;
		this.fcost = cost;
		this.path = path;	
		this.gcost = costPath;
	}

	/**
	 * @return the state
	 */
	public State getState()
	{
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(State state)
	{
		this.state = state;
	}

	/**
	 * @return the cost
	 */
	public double getfCost()
	{
		return fcost;
	}

	/**
	 * @param cost
	 *            the cost to set
	 */
	public void setfCost(double cost)
	{
		this.fcost = cost;
	}

	/**
	 * @return the path
	 */
	public List<Operator> getPath()
	{
		return path;
	}

	/**
	 * @param path the path to set
	 */
	public void setPath(List<Operator> path)
	{
		this.path = path;
	}

	/**
	 * @return the costPath
	 */
	public int getgCost()
	{
		return gcost;
	}

	/**
	 * @param costPath the costPath to set
	 */
	public void setgCost(int costPath)
	{
		this.gcost = costPath;
	}
}
