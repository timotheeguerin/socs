package GridProblem;

import java.util.Comparator;

public class SolverStateComparator implements Comparator<SolverState>
{

	@Override
	public int compare(SolverState state1, SolverState state2)
	{
		if(state1.getfCost() < state2.getfCost())
		{
			return -1;
		}
		else if(state1.getfCost() > state2.getfCost())
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

}
