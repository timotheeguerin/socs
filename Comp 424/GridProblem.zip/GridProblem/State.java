package GridProblem;

public interface State
{
	public abstract void print();
}